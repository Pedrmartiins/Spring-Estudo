package br.com.aweb.hello_spring_boot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HelloSpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
